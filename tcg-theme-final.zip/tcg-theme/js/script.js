/* TCG Theme v1.3.1 JavaScript */
function toggleMenu(){
  var m=document.querySelector('.mobile');
  m.classList.toggle('open');
  document.body.classList.toggle('body-menu-open',m.classList.contains('open'));
}
}

/* Testimonial Carousel with Dots */
var current=0;
var items=document.querySelectorAll('.testimonial');
var dots=document.querySelectorAll('.testimonial-dot');
function show(i){
  if(!items.length)return;
  items[current].classList.remove('active');
  if(dots[current])dots[current].classList.remove('active');
  current=(i+items.length)%items.length;
  items[current].classList.add('active');
  if(dots[current])dots[current].classList.add('active');
}
function next(){show(current+1);rot();}
function prev(){show(current-1);rot();}
var timer;
function rot(){if(timer)clearInterval(timer);timer=setInterval(function(){show(current+1);},5000);}
rot();
dots.forEach(function(d){d.addEventListener('click',function(){show(parseInt(d.dataset.index,10));rot();});});

/* Sticky CTA hides near footer CTA */
var sticky=document.getElementById('sticky-cta');
var footerCta=document.getElementById('page-footer-cta');
if(sticky&&footerCta&&'IntersectionObserver' in window){
  new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      sticky.classList.toggle('sticky-cta-hidden',e.isIntersecting);
    });
  },{threshold:0.2}).observe(footerCta);
}

/* Form submission handler */
document.addEventListener('submit',function(e){
  if(e.target.matches('.lead-form')){
    e.preventDefault();
    alert('Thank you. Your production inquiry has been received. The TCG team will respond within 24 hours.');
  }
});

/* Resource Gate Modal */
var currentResourceName='';
var currentResourceFile='';
function openResourceGate(name,file){
  currentResourceName=name;
  currentResourceFile=file;
  document.getElementById('resourceModalTitle').textContent='Download: '+name;
  document.getElementById('rgResource').value=file;
  document.getElementById('resourceModal').style.display='flex';
}
function closeResourceGate(){
  document.getElementById('resourceModal').style.display='none';
  document.getElementById('resourceGateForm').reset();
}
function submitResourceGate(e){
  e.preventDefault();
  var name=document.getElementById('rgName').value;
  var email=document.getElementById('rgEmail').value;
  var brand=document.getElementById('rgBrand').value;
  var resource=document.getElementById('rgResource').value;
  var leads=JSON.parse(localStorage.getItem('tcg_leads')||'[]');
  leads.push({name:name,email:email,brand:brand,resource:resource,timestamp:new Date().toISOString()});
  localStorage.setItem('tcg_leads',JSON.stringify(leads));
  closeResourceGate();
  var downloadUrl='/wp-content/uploads/resources/'+resource;
  var link=document.createElement('a');
  link.href=downloadUrl;link.download=resource;link.target='_blank';
  document.body.appendChild(link);link.click();document.body.removeChild(link);
  alert('Thank you, '+name+'! Your download is starting now.');
}
document.addEventListener('click',function(e){if(e.target.id==='resourceModal')closeResourceGate();});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){var m=document.getElementById('resourceModal');if(m&&m.style.display==='flex')closeResourceGate();}});
