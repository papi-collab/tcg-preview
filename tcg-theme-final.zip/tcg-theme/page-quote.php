<?php /* Template Name: Quote */ get_header(); ?>

<section class="section">
  <div class="container">
    <div class="two-col">
      <div>
        <h1 class="h1">Get a Production Quote in 24 Hours</h1>
        <div class="gold-line"></div>
        <p class="intro">Tell us what you need. We respond with a clear plan, realistic timeline, and transparent pricing. No obligation. No pressure.</p>
        <div class="metrics" style="margin-top:32px;">
          <div class="metric"><b>16+</b><span>Years</span></div>
          <div class="metric"><b>50</b><span>MOQ</span></div>
          <div class="metric"><b>10K+</b><span>Monthly Capacity</span></div>
          <div class="metric"><b>24h</b><span>Response Time</span></div>
        </div>
        <div class="quick-facts" style="margin-top:32px;">
          <table>
            <tr><td>Minimum Order</td><td>50 units per style/color</td></tr>
            <tr><td>Sampling Time</td><td>7-14 days</td></tr>
            <tr><td>Production Time</td><td>4-8 weeks</td></tr>
            <tr><td>Monthly Capacity</td><td>10,000+ units</td></tr>
            <tr><td>Payment</td><td>50% deposit / 50% before shipping</td></tr>
          </table>
        </div>
        <div style="margin-top:32px;">
          <h3>What Happens Next</h3>
          <ol style="padding-left:20px;font-family:var(--font-body);line-height:2;">
            <li>You submit this form.</li>
            <li>We review your project within 24 hours.</li>
            <li>We send you a clear quote with pricing, timeline, and next steps.</li>
            <li>You decide if you want to proceed. No pressure.</li>
          </ol>
        </div>
      </div>
      <div>
        <div class="form">
          <h3>Tell Us About Your Project</h3>
            <iframe
              id="JotFormIFrame-261407831289058"
              title="TCG Quote Request"
              onload="window.parent.scrollTo(0,0)"
              allowtransparency="true"
              allow="geolocation; microphone; camera; fullscreen"
              src="https://form.jotform.com/261407831289058"
              frameborder="0"
              style="min-width:100%;max-width:100%;height:900px;border:none;"
              scrolling="no"
            ></iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
