<?php /* Template Name: GEO SEO */ get_header();
$slug = get_post_field('post_name', get_post());
$geo_data = array(
  'clothing-manufacturer-usa' => array(
    'title' => 'Clothing Manufacturer for USA Fashion Brands',
    'intro' => 'Premium garment manufacturing from Bali for American fashion brands. 40-60% cost savings with no compromise on quality.',
    'pain_title' => 'The Problem With Finding a Manufacturer From the USA',
    'pain_body' => 'Finding a reliable offshore manufacturer from the US is a gamble. Language barriers, timezone gaps, and factories that disappear after taking your deposit. You need a partner that communicates in real-time and delivers what they promise.',
    'why_title' => 'Why American Brands Choose Bali Manufacturing',
    'benefits' => array(
      '40-60% Cost Savings' => 'Premium quality at a fraction of domestic US manufacturing costs.',
      'Low MOQ (50 Units)' => 'Start small without committing to massive minimums.',
      'English-Speaking Team' => 'Clear communication with no language barriers.',
      'Fast Shipping (10-14 Days)' => 'Sea freight to West Coast in under two weeks.',
      'Full Quality Control' => 'AQL 2.5 inspection standard on every shipment.'
    ),
    'shipping' => 'Sea freight: 10-14 days (West Coast), 14-21 days (East Coast). Air freight: 3-5 days.',
    'region' => 'USA'
  ),
  'clothing-manufacturer-canada' => array(
    'title' => 'Clothing Manufacturer for Canadian Brands',
    'intro' => 'Low MOQ garment manufacturing for Canadian indie labels. Premium quality, competitive pricing, reliable timelines.',
    'pain_title' => 'The Problem With Finding a Manufacturer From Canada',
    'pain_body' => 'Canadian indie brands struggle with high domestic production costs and offshore factories that require 500+ MOQ. You need premium quality at competitive pricing without committing to massive minimums.',
    'why_title' => 'Why Canadian Brands Choose Bali Manufacturing',
    'benefits' => array(
      'Low MOQ (50 Units)' => 'Perfect for emerging Canadian labels and seasonal drops.',
      'Premium Quality' => 'Meets and exceeds Canadian retail standards.',
      'Competitive Pricing' => 'Significant savings vs. domestic Canadian manufacturing.',
      'Reliable Timelines' => '99% on-time delivery rate across all Canadian orders.',
      'Full Service' => 'From sampling to door-to-door delivery in Canada.'
    ),
    'shipping' => 'Sea freight: 14-21 days. Air freight: 4-6 days.',
    'region' => 'Canada'
  ),
  'clothing-manufacturer-australia' => array(
    'title' => 'Clothing Manufacturer for Australian Brands',
    'intro' => 'Same timezone manufacturing from Bali for Australian fashion brands. 5-7 day shipping, premium quality.',
    'pain_title' => 'The Problem With Finding a Manufacturer From Australia',
    'pain_body' => 'Australian brands have a natural advantage with Bali — same timezone, short shipping, and competitive pricing. But finding a factory that maintains Australian retail standards from offshore is still the challenge.',
    'why_title' => 'Why Australian Brands Choose Bali Manufacturing',
    'benefits' => array(
      'Same Timezone' => 'Real-time communication with no overnight delays.',
      'Fast Shipping (5-7 Days)' => 'Sea freight from Bali to Australian ports in under a week.',
      'Australian Retail Standards' => 'Quality that meets and exceeds local expectations.',
      'Low MOQ (50 Units)' => 'Accessible for emerging Australian labels.',
      'Competitive Pricing' => 'Premium quality at a fraction of domestic costs.'
    ),
    'shipping' => 'Sea freight: 5-7 days. Air freight: 2-3 days.',
    'region' => 'Australia'
  ),
  'bali-clothing-manufacturer' => array(
    'title' => 'Bali Clothing Manufacturer',
    'intro' => 'Premium garment manufacturing in Bali, Indonesia. Local expertise, international standards, 16+ years of production experience.',
    'pain_title' => 'The Problem With Finding a Reliable Factory in Bali',
    'pain_body' => 'Bali has hundreds of garment workshops, but quality and reliability vary wildly. Finding a manufacturer with consistent output, proper QC, and the capacity to scale is harder than it looks.',
    'why_title' => 'Why Brands Choose The Clothing Guys in Bali',
    'benefits' => array(
      '16+ Years Experience' => 'One of Bali\'s most established garment manufacturers.',
      'Consistent Quality' => 'Multi-stage QC ensures every unit meets your standard.',
      'Scalable Capacity' => '10,000+ units per month with room to grow.',
      'Full Service' => 'Sampling, production, printing, QC, and shipping under one roof.',
      'Ethical Production' => 'Fair wages, safe conditions, sustainable practices.'
    ),
    'shipping' => 'Local delivery: 1-3 days. Regional shipping: 3-7 days.',
    'region' => 'Bali'
  ),
  'indonesia-garment-manufacturer' => array(
    'title' => 'Indonesia Garment Manufacturer',
    'intro' => 'Full-service garment manufacturing from Indonesia for Southeast Asian and global brands.',
    'pain_title' => 'The Problem With Finding a Manufacturer in Southeast Asia',
    'pain_body' => 'Regional brands need a production partner that understands Asian market speed, pricing expectations, and logistics. Not every Bali factory is set up for regional distribution.',
    'why_title' => 'Why Brands Choose Indonesian Manufacturing',
    'benefits' => array(
      'Regional Hub' => 'Central location for Southeast Asian distribution.',
      'Competitive Pricing' => 'Among the most cost-effective in the region.',
      'Skilled Workforce' => 'Indonesia is a top global garment manufacturing country.',
      'Low MOQ (50 Units)' => 'Accessible for brands of all sizes.',
      'Fast Regional Shipping' => '3-7 days to most Southeast Asian destinations.'
    ),
    'shipping' => 'Regional: 3-7 days. International: 10-21 days (sea).',
    'region' => 'Southeast Asia'
  )
);
$g = isset($geo_data[$slug]) ? $geo_data[$slug] : null;
if(!$g){ echo '<div class="container section"><p>Page not found.</p></div>'; get_footer(); return; }
$faqs = tcg_get_geo_faqs($slug);
?>

<section class="section alt">
  <div class="container">
    <h1 class="h1"><?php echo $g['title']; ?></h1>
    <div class="gold-line"></div>
    <p class="intro"><?php echo $g['intro']; ?></p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title"><?php echo $g['pain_title']; ?></h2>
    <div class="gold-line"></div>
    <p class="intro"><?php echo $g['pain_body']; ?></p>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <h2 class="section-title"><?php echo $g['why_title']; ?></h2>
    <div class="gold-line"></div>
    <div class="grid-3">
      <?php foreach($g['benefits'] as $title => $desc): ?>
      <div class="card">
        <h3><?php echo $title; ?></h3>
        <p><?php echo $desc; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">Services Available for <?php echo $g['region']; ?> Brands</h2>
    <div class="gold-line"></div>
    <ul class="service-list">
      <li><a href="<?php echo home_url('/services/sampling/'); ?>">Sampling & Pattern Making</a></li>
      <li><a href="<?php echo home_url('/services/fabric-sourcing/'); ?>">Fabric Sourcing & Materials</a></li>
      <li><a href="<?php echo home_url('/services/cut-and-sew/'); ?>">Cut & Sew Production</a></li>
      <li><a href="<?php echo home_url('/services/printing-embroidery/'); ?>">Printing & Embroidery</a></li>
      <li><a href="<?php echo home_url('/services/quality-control/'); ?>">Quality Control & Inspection</a></li>
      <li><a href="<?php echo home_url('/services/packaging-shipping/'); ?>">Packaging & Global Shipping</a></li>
    </ul>
    <p class="intro mt-24"><strong>Shipping to <?php echo $g['region']; ?>:</strong> <?php echo $g['shipping']; ?></p>
  </div>
</section>

<?php if(!empty($faqs)): ?>
<section class="section alt">
  <div class="container">
    <h2 class="section-title">Common Questions from <?php echo $g['region']; ?> Brands</h2>
    <div class="gold-line"></div>
    <div class="faq">
      <?php foreach($faqs as $q => $a): ?>
      <details>
        <summary><?php echo $q; ?></summary>
        <p><?php echo $a; ?></p>
      </details>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Ready to Start Production?</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Get a free quote with pricing, timeline, and shipping estimate to <?php echo $g['region']; ?>.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Free Quote</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
