<?php /* Template Name: Home */ get_header(); ?>
<section class="banner" id="hero-banner">
  <div class="container banner-grid">
    <div class="banner-logo-wrap">
      <img src="<?php echo home_url('/wp-content/uploads/logos/TCG_Logo_Black.png'); ?>" alt="The Clothing Guys" class="banner-logo-img">
    </div>
    <div>
      <div class="metrics">
        <div class="metric"><b>16+</b><span>Years in Production</span></div>
        <div class="metric"><b>100+</b><span>Brands Delivered</span></div>
        <div class="metric"><b>99%</b><span>On-Time Rate</span></div>
        <div class="metric"><b>50</b><span>Unit MOQ</span></div>
      </div>
    </div>
  </div>
</section>
<section class="hero">
  <div class="container hero-inner">
    <span class="eyebrow">Bali-Based Garment Manufacturing</span>
    <h1 class="h1">Your Designs Deserve a Factory That Actually Delivers.</h1>
    <p class="lead">Most emerging brands lose months to unreliable manufacturers — missed deadlines, inconsistent quality, and zero communication. The Clothing Guys is the production partner that shows up. From 50-piece sampling to 10,000-unit runs. On time. On spec. Full transparency.</p>
    <div class="btn-row btn-row-left">
      <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Free Production Quote</a>
      <a class="btn btn-outline" href="<?php echo home_url('/process/'); ?>">See How It Works</a>
    </div>
  </div>
</section>

<!-- How It Works — Three-Step Bridge -->
<section class="section alt">
  <div class="container">
    <h2 class="section-title">How It Works</h2>
    <div class="gold-line"></div>
    <p class="intro">Three steps from concept to delivered product. No guesswork. No surprises.</p>
    <div class="grid-3 mt-24">
      <div class="card card-center">
        <img src="/wp-content/uploads/logos/bg7-fabric-dyeing.jpg" alt="Tell us your requirements" class="card-img">
        <div class="icon">1</div>
        <h3>Tell Us What You Need</h3>
        <p>Share your designs, quantities, and timeline. We respond within 24 hours with a clear production plan and pricing.</p>
      </div>
      <div class="card card-center">
        <img src="/wp-content/uploads/logos/bg4-labelling.jpg" alt="Approve samples" class="card-img">
        <div class="icon">2</div>
        <h3>Approve Samples Before Bulk</h3>
        <p>We produce samples for your review. You approve fit, fabric, and finishing before a single bulk unit is cut.</p>
      </div>
      <div class="card card-center">
        <div class="icon">3</div>
        <img src="/wp-content/uploads/logos/bg1-pattern-making.jpg" alt="Manufacturing in progress" class="card-img">
        <h3>We Manufacture and Ship</h3>
        <p>Production runs on schedule with quality checks at every stage. We ship directly to your warehouse or fulfillment center.</p>
      </div>
    </div>
  </div>
</section>

<!-- Services Section -->
<section class="section">
  <div class="container">
    <h2 class="section-title">What We Manufacture</h2>
    <div class="gold-line"></div>
    <div class="grid-3">
      <a class="card-link" href="<?php echo home_url('/services/cut-and-sew/'); ?>">
        <div class="card"><img src="/wp-content/uploads/logos/bg6-screen-printing.jpg" alt="Cut and Sew Production" class="card-img"><div class="icon">C&amp;S</div><h3>Cut & Sew Production</h3><p>Full garment construction for any category. Consistent sizing, premium finishing, production-ready from day one.</p><span class="btn btn-outline">Learn more &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/printing-embroidery/'); ?>">
        <div class="card"><img src="/wp-content/uploads/logos/bg8-shipping.jpg" alt="Printing and Embroidery" class="card-img"><div class="icon">P</div><h3>Printing & Embroidery</h3><p>Screen print, DTG, sublimation, and embroidery. Your artwork applied with precision at any scale.</p><span class="btn btn-outline">Learn more &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/sampling/'); ?>">
        <div class="card"><img src="/wp-content/uploads/logos/bg2-hero.jpg" alt="Sampling and Pattern Making" class="card-img"><div class="icon">S</div><h3>Sampling & Pattern Making</h3><p>From sketch to production-ready pattern. We develop samples you can approve before committing to bulk.</p><span class="btn btn-outline">Learn more &rarr;</span></div>
      </a>
    </div>
  </div>
</section>

<!-- Categories Section -->
<section class="section alt">
  <div class="container">
    <h2 class="section-title">Built for Every Category</h2>
    <div class="gold-line"></div>
    <div class="grid-4">
      <a class="card-link" href="<?php echo home_url('/streetwear/'); ?>"><div class="card card-center"><h3>Streetwear</h3><p>Hoodies, tees, joggers, outerwear</p></div></a>
      <a class="card-link" href="<?php echo home_url('/activewear/'); ?>"><div class="card card-center"><h3>Activewear</h3><p>Leggings, sports bras, shorts, performance tops</p></div></a>
      <a class="card-link" href="<?php echo home_url('/womenswear/'); ?>"><div class="card card-center"><h3>Womenswear</h3><p>Dresses, blouses, skirts, resort wear</p></div></a>
      <a class="card-link" href="<?php echo home_url('/uniforms/'); ?>"><div class="card card-center"><h3>Uniforms</h3><p>Corporate, hospitality, workwear</p></div></a>
    </div>
  </div>
</section>

<!-- Production Capacity -->
<section class="section">
  <div class="container">
    <h2 class="section-title">Production Capacity at Scale</h2>
    <div class="gold-line"></div>
    <div class="metrics">
      <div class="metric"><b>50M+</b><span>Units Produced</span></div>
      <div class="metric"><b>10K+</b><span>Monthly Capacity</span></div>
      <div class="metric"><b>4-8</b><span>Weeks Lead Time</span></div>
      <div class="metric"><b>100%</b><span>Quality Inspected</span></div>
    </div>
    <p class="intro" style="margin-top:24px;">Every unit passes multi-stage quality control before shipment. References available on request.</p>
  </div>
</section>

<!-- Regions Section -->
<section class="section alt">
  <div class="container">
    <h2 class="section-title">We Ship to Brands In</h2>
    <div class="gold-line"></div>
    <div class="grid-3">
      <a class="card-link" href="<?php echo home_url('/clothing-manufacturer-usa/'); ?>"><div class="card card-center"><h3>United States</h3><p>40-60% savings vs. domestic. 10-14 day shipping.</p></div></a>
      <a class="card-link" href="<?php echo home_url('/clothing-manufacturer-canada/'); ?>"><div class="card card-center"><h3>Canada</h3><p>Low MOQ production for Canadian indie labels.</p></div></a>
      <a class="card-link" href="<?php echo home_url('/clothing-manufacturer-australia/'); ?>"><div class="card card-center"><h3>Australia</h3><p>Same timezone. 5-7 day shipping from Bali.</p></div></a>
      <a class="card-link" href="<?php echo home_url('/bali-clothing-manufacturer/'); ?>"><div class="card card-center"><h3>Bali / Indonesia</h3><p>Local expertise, premium craftsmanship.</p></div></a>
      <a class="card-link" href="<?php echo home_url('/indonesia-garment-manufacturer/'); ?>"><div class="card card-center"><h3>Southeast Asia</h3><p>Regional production hub for Asian markets.</p></div></a>
      <a class="card-link" href="<?php echo home_url('/quote/'); ?>"><div class="card card-center"><h3>Other Regions</h3><p>We ship globally. Get a quote for your location.</p></div></a>
    </div>
  </div>
</section>

<!-- Testimonials Section -->
<section class="section">
  <div class="container">
    <h2 class="section-title">Brands That Trust Us With Production</h2>
    <div class="gold-line"></div>
    <div class="testimonial-stage">
      <div class="testimonial active">
        <div class="quote-box">
          <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <blockquote>Working with The Clothing Guys has been a seamless experience. Their communication is professional, pricing is transparent, and they are always willing to accommodate adjustments. Highly recommended for anyone looking for reliable garment manufacturing.</blockquote>
          <p><strong>Tenplus</strong> — Indonesia</p>
        </div>
      </div>
      <div class="testimonial">
        <div class="quote-box">
          <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <blockquote>The quality of the custom T-shirts and tank tops exceeded our expectations. Comfortable, great fit, and you can tell they genuinely care about the final product. Will definitely be ordering again.</blockquote>
          <p><strong>Zutti Inc</strong> — Canada</p>
        </div>
      </div>
      <div class="testimonial">
        <div class="quote-box">
          <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <blockquote>We ordered custom apparel for our team and the quality, fit, and professionalism exceeded expectations. The Clothing Guys delivered exactly what we needed — our team looks sharp and consistent.</blockquote>
          <p><strong>Campoli Electric</strong> — Canada</p>
        </div>
      </div>
      <div class="testimonial">
        <div class="quote-box">
          <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <blockquote>Great work all the way through. They speak the language, communicate fast, and handle everything from samples to production. Easy to work with and reliable.</blockquote>
          <p><strong>Elephant Shoe</strong> — Indonesia</p>
        </div>
      </div>
      <div class="testimonial">
        <div class="quote-box">
          <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <blockquote>Bocce Canada has been working with The Clothing Guys for our custom apparel needs and the experience has been outstanding. Quality product, reliable timelines, and great communication throughout.</blockquote>
          <p><strong>Bocce Canada</strong> — Canada</p>
        </div>
      </div>
      <div class="testimonial">
        <div class="quote-box">
          <div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <blockquote>Good production and good communication. They helped with pattern and cutting on silk which is technically demanding. Exactly what we needed.</blockquote>
          <p><strong>Chance Design</strong> — Indonesia</p>
        </div>
      </div>
    </div>
    <div class="testimonial-controls">
      <div class="testimonial-dots">
        <button class="testimonial-dot active" data-index="0" aria-label="Testimonial 1"></button>
        <button class="testimonial-dot" data-index="1" aria-label="Testimonial 2"></button>
        <button class="testimonial-dot" data-index="2" aria-label="Testimonial 3"></button>
        <button class="testimonial-dot" data-index="3" aria-label="Testimonial 4"></button>
        <button class="testimonial-dot" data-index="4" aria-label="Testimonial 5"></button>
        <button class="testimonial-dot" data-index="5" aria-label="Testimonial 6"></button>
      </div>
      <div class="testimonial-nav">
        <button class="btn btn-outline" onclick="prev()">&larr; Prev</button>
        <button class="btn btn-outline" onclick="next()">Next &rarr;</button>
      </div>
    </div>
  </div>
</section>

<!-- Bottom CTA -->
<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Ready to Start Production?</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Tell us what you need. Our team responds within 24 hours with a clear plan, pricing, and timeline.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Free Quote</a>
  </div>
</section>

<!-- Sticky CTA -->
<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
