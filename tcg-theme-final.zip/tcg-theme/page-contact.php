<?php get_header(); ?>
<section class="section alt">
    <div class="container">
        <h1 class="section-title">Contact The Clothing Guys</h1>
        <div class="gold-line"></div>
        <p class="intro">Ready to discuss your manufacturing project? Fill out the form below and our production team will respond within 24 hours.</p>
    </div>
</section>
<section class="section">
    <div class="container grid-2">
        <form class="form lead-form">
            <h3 style="margin-bottom:18px">Tell Us About Your Project</h3>
            <input placeholder="Full Name *" required aria-label="Full Name">
            <input placeholder="Email Address *" type="email" required aria-label="Email Address">
            <input placeholder="Brand / Company Name *" required aria-label="Brand Name">
            <input placeholder="Website or Instagram URL" aria-label="Website or Instagram">
            <select aria-label="Product Category">
                <option value="">Product Category *</option>
                <option>Streetwear</option>
                <option>Activewear</option>
                <option>Womenswear</option>
                <option>Menswear</option>
                <option>Uniforms / Workwear</option>
                <option>Resort Wear</option>
                <option>Other</option>
            </select>
            <select aria-label="Estimated Quantity">
                <option value="">Estimated Quantity per Style</option>
                <option>50 - 100 units</option>
                <option>100 - 500 units</option>
                <option>500 - 1,000 units</option>
                <option>1,000 - 5,000 units</option>
                <option>5,000+ units</option>
                <option>Not sure yet</option>
            </select>
            <select aria-label="Timeline">
                <option value="">Production Timeline</option>
                <option>ASAP / Urgent</option>
                <option>Within 1 month</option>
                <option>1-3 months</option>
                <option>3-6 months</option>
                <option>Just exploring options</option>
            </select>
            <select aria-label="Budget Range">
                <option value="">Budget Range (per unit)</option>
                <option>Under $10</option>
                <option>$10 - $25</option>
                <option>$25 - $50</option>
                <option>$50 - $100</option>
                <option>$100+</option>
                <option>Not sure yet</option>
            </select>
            <textarea placeholder="Tell us about your project: What are you looking to manufacture? Any specific requirements?" rows="5" aria-label="Project Details"></textarea>
            <button class="btn btn-gold" style="width:100%">Send Inquiry</button>
        </form>
        <div>
            <div class="card" style="margin-bottom:20px">
                <h3>Direct Contact</h3>
                <p style="margin:12px 0"><strong>Email:</strong> info@theclothingguys.com</p>
                <p style="margin:12px 0"><strong>WhatsApp:</strong> <a href="https://wa.me/message/TCG">Message us on WhatsApp</a></p>
                <p style="margin:12px 0"><strong>Location:</strong> Bali, Indonesia</p>
                <p style="margin:12px 0"><strong>Hours:</strong> Mon-Fri 9:00 AM - 6:00 PM (WITA)</p>
            </div>
            <div class="card" style="margin-bottom:20px">
                <h3>What Happens Next?</h3>
                <p style="padding:8px 0;border-bottom:1px solid var(--line)"><strong>1.</strong> We review your inquiry within 24 hours</p>
                <p style="padding:8px 0;border-bottom:1px solid var(--line)"><strong>2.</strong> Our team schedules a consultation call</p>
                <p style="padding:8px 0;border-bottom:1px solid var(--line)"><strong>3.</strong> We provide a detailed quote and timeline</p>
                <p style="padding:8px 0"><strong>4.</strong> Sampling begins upon approval</p>
            </div>
            <div class="card">
                <h3>Manufacturing Locations</h3>
                <p style="margin:8px 0">We serve brands in:</p>
                <p><a href="<?php echo home_url('/clothing-manufacturer-usa/'); ?>">United States</a> | <a href="<?php echo home_url('/clothing-manufacturer-canada/'); ?>">Canada</a> | <a href="<?php echo home_url('/clothing-manufacturer-australia/'); ?>">Australia</a> | <a href="<?php echo home_url('/bali-clothing-manufacturer/'); ?>">Bali</a> | <a href="<?php echo home_url('/indonesia-garment-manufacturer/'); ?>">Indonesia</a></p>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>
