<?php
/**
 * Template Name: Geo Landing Page
 */
get_header();

// Get page slug to determine which geo page
$slug = get_post_field('post_name', get_post());
$geo_data = array(
    'geo-usa' => array(
        'title' => 'Clothing Manufacturer for USA Fashion Brands',
        'desc' => 'Premium offshore garment manufacturing for USA fashion brands. Direct communication, competitive pricing, and reliable delivery from Bali to the United States.',
        'region' => 'USA',
        'benefits' => array(
            'Direct English-speaking communication with no timezone barriers',
            '40-60% cost savings compared to domestic US manufacturing',
            '2-3 week turnaround on sampling with express shipping options',
            'Ethical manufacturing with full supply chain transparency',
            'Flexible MOQ starting at just 50 units per style'
        )
    ),
    'geo-canada' => array(
        'title' => 'Clothing Manufacturer for Canadian Fashion Brands',
        'desc' => 'Premium offshore garment manufacturing for Canadian fashion brands. Reliable production, competitive pricing, and seamless logistics from Bali to Canada.',
        'region' => 'Canada',
        'benefits' => array(
            'Direct English-speaking communication throughout production',
            'Significant cost savings compared to Canadian domestic manufacturing',
            'Express sampling and production timelines',
            'Ethical and sustainable manufacturing practices',
            'Low MOQ starting at 50 units for emerging Canadian brands'
        )
    ),
    'geo-australia' => array(
        'title' => 'Clothing Manufacturer for Australian Fashion Brands',
        'desc' => 'Premium offshore garment manufacturing for Australian fashion brands. Close timezone alignment, competitive pricing, and fast shipping from Bali.',
        'region' => 'Australia',
        'benefits' => array(
            'Close timezone alignment for real-time communication',
            '50-70% cost savings compared to Australian domestic production',
            'Fast shipping — Bali to Australia in 5-7 business days',
            'Ethical manufacturing with full traceability',
            'Flexible MOQ starting at 50 units per style'
        )
    ),
    'geo-europe' => array(
        'title' => 'Clothing Manufacturer for European Fashion Brands',
        'desc' => 'Premium offshore garment manufacturing for European fashion brands. Quality production, competitive pricing, and reliable logistics from Bali to Europe.',
        'region' => 'Europe',
        'benefits' => array(
            'Direct communication in English throughout production',
            'Significant cost savings compared to European manufacturing',
            'Premium quality meeting European market standards',
            'Sustainable and ethical production practices',
            'Flexible MOQ starting at 50 units for emerging brands'
        )
    ),
    'geo-southeast-asia' => array(
        'title' => 'Clothing Manufacturer for Southeast Asian Fashion Brands',
        'desc' => 'Premium garment manufacturing for Southeast Asian fashion brands. Local expertise, competitive pricing, and fast regional delivery from Bali.',
        'region' => 'Southeast Asia',
        'benefits' => array(
            'Same-region production with fast delivery times',
            'Competitive pricing with premium quality standards',
            'Cultural understanding of regional fashion markets',
            'Sustainable manufacturing practices',
            'Flexible MOQ starting at 50 units per style'
        )
    ),
);

$data = isset($geo_data[$slug]) ? $geo_data[$slug] : $geo_data['geo-usa'];
?>

<section class="section alt">
    <div class="container">
        <h1 class="section-title"><?php echo esc_html($data['title']); ?></h1>
        <div class="gold-line"></div>
        <p class="intro"><?php echo esc_html($data['desc']); ?></p>
    </div>
</section>

<section class="section">
    <div class="container grid-2">
        <div>
            <h2 class="section-title">Why <?php echo esc_html($data['region']); ?> Brands Choose TCG</h2>
            <div class="gold-line"></div>
            <?php foreach ($data['benefits'] as $benefit) : ?>
                <p style="padding:8px 0;border-bottom:1px solid var(--line)">&#10003; <?php echo esc_html($benefit); ?></p>
            <?php endforeach; ?>
        </div>
        <div>
            <div class="card">
                <h3>Full-Service Manufacturing</h3>
                <p>We manage the production lifecycle from concept to delivery for <?php echo esc_html($data['region']); ?> brands.</p>
                <p><strong>Design &amp; Development</strong> — Pattern making, fit refinement, sampling, and prototyping.</p>
                <p><strong>Fabric &amp; Materials</strong> — Premium cottons, technical fabrics, sustainable options.</p>
                <p><strong>Production &amp; Printing</strong> — Cut and sew, screen printing, digital printing, embroidery.</p>
                <p><strong>Packaging &amp; Logistics</strong> — Labels, tags, retail-ready packaging, global shipping.</p>
            </div>
        </div>
    </div>
</section>

<section class="section alt">
    <div class="container">
        <div class="metrics">
            <div class="metric"><b>100+</b><span>Global Brands</span></div>
            <div class="metric"><b>99%</b><span>On-Time Delivery</span></div>
            <div class="metric"><b>16+</b><span>Years Experience</span></div>
            <div class="metric"><b>50</b><span>MOQ</span></div>
        </div>
    </div>
</section>

<section class="section dark">
    <div class="container" style="text-align:center">
        <h2 class="section-title">Ready to Start Your Project?</h2>
        <p class="intro" style="margin:auto auto 24px">Get a detailed quote for your manufacturing needs. Our team will respond within 24 hours.</p>
        <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Request a Quote</a>
    </div>
</section>

<?php get_footer(); ?>
