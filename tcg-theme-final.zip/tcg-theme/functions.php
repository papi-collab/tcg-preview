<?php
/* TCG Theme Functions v1.3.2 */

/* ---- Enqueue Scripts & Styles ---- */
function tcg_scripts(){
    wp_enqueue_style('tcg-style', get_stylesheet_uri(), array(), '1.4.1');
    wp_enqueue_script('tcg-script', get_template_directory_uri().'/js/script.js', array(), '1.4.1', true);
}
add_action('wp_enqueue_scripts','tcg_scripts');

/* ---- SEO Meta Tags ---- */
function tcg_seo_meta(){
    if(is_front_page()){
        $title = 'The Clothing Guys | Premium Garment Manufacturing from Bali';
        $desc = 'Your designs deserve a factory that actually delivers. Premium garment manufacturing from Bali, Indonesia. Cut & sew, printing, sampling, QC, and global shipping. 50-unit MOQ. 100+ brands served.';
    } else {
        $title = get_the_title() . ' | The Clothing Guys';
        $desc = get_the_excerpt() ?: 'Premium garment manufacturing from Bali, Indonesia. From concept to delivery.';
    }
    echo '<title>' . esc_html($title) . '</title>' . "\n";
    echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
    echo '<link rel="canonical" href="' . esc_url(get_permalink()) . '">' . "\n";
    /* Open Graph */
    echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
    echo '<meta property="og:type" content="website">' . "\n";
    echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '">' . "\n";
    echo '<meta property="og:image" content="' . esc_url(home_url('/wp-content/uploads/logos/TCG_Logo_Concept3.png')) . '">' . "\n";
}
add_action('wp_head','tcg_seo_meta',1);
remove_action('wp_head','_wp_render_title_tag',1);

/* ---- Schema Markup ---- */
function tcg_schema_markup(){
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'ClothingStore',
        'name' => 'The Clothing Guys',
        'description' => 'Premium garment manufacturing from Bali, Indonesia. Cut & sew, printing, sampling, QC, and global shipping.',
        'url' => home_url('/'),
        'logo' => home_url('/wp-content/uploads/logos/TCG_Logo_Concept3.png'),
        'telephone' => '+6282230100897',
        'email' => 'info@theclothingguys.com',
        'address' => array(
            '@type' => 'PostalAddress',
            'addressLocality' => 'Bali',
            'addressCountry' => 'ID'
        ),
        'areaServed' => array('US','CA','AU','ID','SG','GB'),
        'priceRange' => '$$',
        'foundingDate' => '2010',
        'sameAs' => array(
            'https://www.instagram.com/theclothingguys/'
        )
    );
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}
add_action('wp_head','tcg_schema_markup');

/* ---- GEO FAQ Schema ---- */
function tcg_faq_schema(){
    $slug = get_post_field('post_name', get_post());
    $faqs = tcg_get_geo_faqs($slug);
    if(empty($faqs)) return;
    $items = array();
    foreach($faqs as $q => $a){
        $items[] = array(
            '@type' => 'Question',
            'name' => $q,
            'acceptedAnswer' => array('@type' => 'Answer', 'text' => $a)
        );
    }
    $schema = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items);
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}
add_action('wp_head','tcg_faq_schema');

/* ---- GEO FAQ Data ---- */
function tcg_get_geo_faqs($slug){
    $all_faqs = array(
        'clothing-manufacturer-usa' => array(
            'What is the cost of manufacturing clothing in Bali vs USA?' => 'Brands typically save 40-60% compared to domestic US manufacturing while maintaining premium quality standards.',
            'What is the shipping time from Bali to the USA?' => 'Sea freight takes 10-14 business days to West Coast, 14-21 days to East Coast. Air freight is 3-5 business days.',
            'Can I visit the factory in Bali?' => 'Absolutely. We welcome factory visits and can arrange tours of our production facility in Bali.',
            'What is the minimum order for US brands?' => 'Our MOQ starts at 50 units per style/color, making us accessible for emerging US fashion brands.'
        ),
        'clothing-manufacturer-canada' => array(
            'How long does shipping take from Bali to Canada?' => 'Sea freight takes 14-21 business days. Air freight is 4-6 business days. We manage end-to-end logistics.',
            'What is the minimum order for Canadian brands?' => 'Our MOQ starts at 50 units per style, making us accessible for emerging Canadian fashion brands.',
            'Do you handle Canadian customs paperwork?' => 'Yes. We manage all export documentation and customs clearance for Canadian shipments.',
            'Can you produce small batch seasonal drops?' => 'Yes. Our 50-unit MOQ is designed for brands running seasonal collections and limited drops.'
        ),
        'clothing-manufacturer-australia' => array(
            'How fast can you ship to Australia?' => 'Sea freight from Bali to Australian ports takes 5-7 business days. Air freight is 2-3 days.',
            'Is Bali manufacturing good quality for Australian brands?' => 'Absolutely. Our quality meets and exceeds Australian retail standards. We produce for multiple Australian labels.',
            'What timezone do you operate in?' => 'We operate in WITA (GMT+8), which is the same timezone as Perth and only 2-3 hours behind Sydney/Melbourne.',
            'What is the minimum order for Australian brands?' => 'Our MOQ starts at 50 units per style/color.'
        ),
        'bali-clothing-manufacturer' => array(
            'Why choose Bali for clothing manufacturing?' => 'Bali offers a unique combination of skilled craftsmanship, competitive pricing, ethical production, and a strong textile tradition.',
            'What types of garments can you manufacture in Bali?' => 'We manufacture all garment types: streetwear, activewear, womenswear, menswear, uniforms, resort wear, and more.',
            'How long has The Clothing Guys been operating in Bali?' => 'We have been manufacturing in Bali since 2010 (originally as BaliLab), with 16+ years of production experience.',
            'Can I visit your factory?' => 'Yes. We welcome factory visits and can arrange tours of our production facility.'
        ),
        'indonesia-garment-manufacturer' => array(
            'Is Indonesia a good country for garment manufacturing?' => 'Yes, Indonesia is one of the top garment manufacturing countries globally, known for quality craftsmanship, competitive pricing, and a large skilled workforce.',
            'What is the MOQ for manufacturing in Indonesia?' => 'Our MOQ starts at 50 units per style, which is among the lowest in the Indonesian garment industry.',
            'How does Indonesian manufacturing compare to China?' => 'Indonesia offers comparable quality with more flexibility on MOQ, faster communication, and competitive pricing for small-to-medium brands.',
            'What certifications do you hold?' => 'We follow ethical production standards and can work with GOTS-certified organic materials on request.'
        )
    );
    return isset($all_faqs[$slug]) ? $all_faqs[$slug] : array();
}

/* ---- Template routing ---- */
function tcg_page_template_redirect(){
    if(is_page()){
        $slug = get_post_field('post_name', get_post());
        $map = array(
            'home'=>'page-home.php',
            'services'=>'page-services.php',
            'about'=>'page-about.php',
            'process'=>'page-process.php',
            'resources'=>'page-resources.php',
            'blog-page'=>'page-blog.php',
            'contact'=>'page-contact.php',
            'quote'=>'page-quote.php',
            'case-studies'=>'page-case-studies.php',
            /* Service pages */
            'sampling'=>'page-service-single.php',
            'fabric-sourcing'=>'page-service-single.php',
            'cut-and-sew'=>'page-service-single.php',
            'printing-embroidery'=>'page-service-single.php',
            'quality-control'=>'page-service-single.php',
            'packaging-shipping'=>'page-service-single.php',
            /* GEO pages */
            'geo-usa'=>'page-geo.php',
            'geo-canada'=>'page-geo.php',
            'geo-australia'=>'page-geo.php',
            'geo-europe'=>'page-geo.php',
            'geo-southeast-asia'=>'page-geo.php',
            'clothing-manufacturer-usa'=>'page-geo-seo.php',
            'clothing-manufacturer-canada'=>'page-geo-seo.php',
            'clothing-manufacturer-australia'=>'page-geo-seo.php',
            'bali-clothing-manufacturer'=>'page-geo-seo.php',
            'indonesia-garment-manufacturer'=>'page-geo-seo.php',
            /* Category pages */
            'streetwear'=>'page-category.php',
            'activewear'=>'page-category.php',
            'womenswear'=>'page-category.php',
            'uniforms'=>'page-category.php',
            /* Blog pages */
            'blog-choose-manufacturer'=>'page-blog-post.php',
            'blog-what-is-moq'=>'page-blog-post.php',
            'blog-streetwear-guide'=>'page-blog-post.php',
            'blog-activewear-guide'=>'page-blog-post.php',
            'blog-bali-vs-china'=>'page-blog-post.php',
            'blog-quality-control'=>'page-blog-post.php'
        );
        if(isset($map[$slug])){
            $t = locate_template($map[$slug]);
            if($t){include($t);exit;}
        }
    }
}
add_action('template_redirect','tcg_page_template_redirect');

/* ---- Set Front Page ---- */
function tcg_set_front_page(){
    $p = get_page_by_path('home');
    if($p){update_option('show_on_front','page');update_option('page_on_front',$p->ID);}
}
add_action('after_switch_theme','tcg_set_front_page');

/* ---- XML Sitemap ---- */
function tcg_custom_sitemap(){
    if(isset($_GET['tcg-sitemap']) && $_GET['tcg-sitemap'] === 'xml'){
        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $pages = get_pages(array('post_status' => 'publish'));
        foreach($pages as $p){
            $url = get_permalink($p->ID);
            $mod = get_the_modified_date('Y-m-d', $p->ID);
            $priority = ($p->post_name === 'home') ? '1.0' : '0.8';
            echo "<url><loc>{$url}</loc><lastmod>{$mod}</lastmod><priority>{$priority}</priority></url>\n";
        }
        echo '</urlset>';
        exit;
    }
}
add_action('init','tcg_custom_sitemap');
remove_action('wp_head','wp_generator');
