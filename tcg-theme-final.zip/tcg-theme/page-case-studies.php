<?php /* Template Name: Case Studies */ get_header(); ?>

<section class="section alt">
  <div class="container">
    <h1 class="h1">Production Results for Real Brands</h1>
    <div class="gold-line"></div>
    <p class="intro">Outcomes from brands that faced the same production challenges you are facing now.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">Client Outcomes</h2>
    <div class="gold-line"></div>
    <div class="grid-3">
      <div class="card">
        <h3>Tenplus — Indonesia</h3>
        <p><strong>Problem:</strong> Needed a manufacturer with professional communication, transparent pricing, and willingness to accommodate adjustments during production.</p>
        <p><strong>Solution:</strong> TCG assigned a dedicated account manager, provided real-time production updates, and built in revision flexibility at each stage.</p>
        <p><strong>Result:</strong> Seamless production process. Consistent quality across multiple orders with fair, transparent pricing.</p>
      </div>
      <div class="card">
        <h3>Zutti Inc — Canada</h3>
        <p><strong>Problem:</strong> Needed custom T-shirts and tank tops for their business but could not find a manufacturer that delivered quality matching their brand standards.</p>
        <p><strong>Solution:</strong> TCG produced custom garments with premium fabric, consistent fit, and quality finishing that exceeded expectations.</p>
        <p><strong>Result:</strong> Quality exceeded expectations. Comfortable, great fit, and a production partner that genuinely cares about the final product.</p>
      </div>
      <div class="card">
        <h3>Campoli Electric — Canada</h3>
        <p><strong>Problem:</strong> Needed promotional apparel that would give their team a strong, consistent presence both on-site and with clients.</p>
        <p><strong>Solution:</strong> TCG produced custom branded apparel with premium quality, professional fit, and consistent finishing across the full order.</p>
        <p><strong>Result:</strong> Professional brand presence achieved. Quality, fit, and professionalism exceeded expectations across the entire team.</p>
      </div>
      <div class="card">
        <h3>Elephant Shoe — Indonesia</h3>
        <p><strong>Problem:</strong> Needed a manufacturer that spoke the language, communicated fast, and could handle both samples and production reliably.</p>
        <p><strong>Solution:</strong> TCG provided clear English communication, fast replies, and managed the full process from sampling through bulk production.</p>
        <p><strong>Result:</strong> Great work all the way through. Easy communication, fast responses, and reliable production from start to finish.</p>
      </div>
      <div class="card">
        <h3>Chance Design — Indonesia</h3>
        <p><strong>Problem:</strong> Needed help with pattern and cutting on silk — a technically demanding fabric that most factories struggle with.</p>
        <p><strong>Solution:</strong> TCG provided expert pattern making and precision cutting on silk, with clear communication throughout the process.</p>
        <p><strong>Result:</strong> Exactly what they needed. Good production, good communication, and technical expertise on difficult fabrics.</p>
      </div>
      <div class="card">
        <h3>Bocce Canada — Canada</h3>
        <p><strong>Problem:</strong> Needed custom apparel for their brand with reliable timelines and consistent quality across multiple orders.</p>
        <p><strong>Solution:</strong> TCG delivered quality product with reliable timelines and great communication throughout the production process.</p>
        <p><strong>Result:</strong> Outstanding experience. Quality product, reliable timelines, and great communication throughout.</p>
      </div>
    </div>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <div class="metrics">
      <div class="metric"><b>100+</b><span>Global Brands</span></div>
      <div class="metric"><b>99%</b><span>On-Time Delivery</span></div>
      <div class="metric"><b>16+</b><span>Years Experience</span></div>
      <div class="metric"><b>50</b><span>Unit MOQ</span></div>
    </div>
  </div>
</section>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Your Brand Could Be Next</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Tell us your production challenge. We will show you how we solve it.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Start Your Project</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
