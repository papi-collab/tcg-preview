<?php /* Template Name: Services */ get_header(); ?>

<section class="section alt hero-bg" style="background:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url(/wp-content/uploads/logos/background-1.jpg) center/cover no-repeat;color:#fff">
  <div class="container">
    <h1 class="h1">End-to-End Garment Manufacturing</h1>
    <div class="gold-line"></div>
    <p class="intro">From pattern making to global shipping. One production partner handles everything so you can focus on selling.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">Every Stage of Production, Handled</h2>
    <div class="gold-line"></div>
    <p class="intro">Most brands piece together 4-5 vendors for one production run. We handle the full lifecycle under one roof.</p>
    <div class="grid-3 mt-24">
      <a class="card-link" href="<?php echo home_url('/services/sampling/'); ?>">
        <div class="card"><div class="icon">S</div><h3>Sampling & Pattern Making</h3><p>We turn your sketches or tech packs into production-ready patterns and samples. Approve fit and construction before committing to bulk.</p><span class="btn btn-outline">View Service &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/fabric-sourcing/'); ?>">
        <div class="card"><div class="icon">F</div><h3>Fabric Sourcing & Materials</h3><p>Premium cottons, technical performance fabrics, sustainable options, and custom dyeing. We source what your product needs.</p><span class="btn btn-outline">View Service &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/cut-and-sew/'); ?>">
        <div class="card"><div class="icon">C&amp;S</div><h3>Cut & Sew Production</h3><p>Full garment construction from 50 to 10,000+ units. Consistent sizing, premium finishing, on-time delivery.</p><span class="btn btn-outline">View Service &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/printing-embroidery/'); ?>">
        <div class="card"><div class="icon">P</div><h3>Printing & Embroidery</h3><p>Screen printing, DTG, sublimation, and embroidery. Your designs applied with precision at any volume.</p><span class="btn btn-outline">View Service &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/quality-control/'); ?>">
        <div class="card"><div class="icon">QC</div><h3>Quality Control & Inspection</h3><p>Multi-stage inspection at every production phase. AQL standards. Nothing ships without passing QC.</p><span class="btn btn-outline">View Service &rarr;</span></div>
      </a>
      <a class="card-link" href="<?php echo home_url('/services/packaging-shipping/'); ?>">
        <div class="card"><div class="icon">&#9992;</div><h3>Packaging & Global Shipping</h3><p>Custom labels, tags, retail-ready packaging, and door-to-door logistics to any country.</p><span class="btn btn-outline">View Service &rarr;</span></div>
      </a>
    </div>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <h2 class="section-title">Why Brands Choose One Production Partner</h2>
    <div class="gold-line"></div>
    <div class="two-col">
      <div>
        <p class="intro">Coordinating between a pattern maker, fabric supplier, printer, sewing factory, and logistics company creates gaps. Timelines slip. Quality varies. Communication breaks down.</p>
        <p class="intro" style="margin-top:16px;">The Clothing Guys manages every stage internally. One point of contact. One timeline. One quality standard.</p>
      </div>
      <div>
        <ul class="service-list">
          <li>Single point of contact for the entire production run</li>
          <li>No miscommunication between vendors</li>
          <li>Consistent quality from sampling through bulk</li>
          <li>Faster turnaround with integrated production</li>
          <li>Transparent pricing with no hidden middleman fees</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Tell Us What You Need</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Describe your project and we will respond within 24 hours with a production plan, timeline, and pricing.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Request a Quote</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
