<?php /* Template Name: Resources */ get_header(); ?>

<section class="section alt">
  <div class="container">
    <h1 class="h1">Production Guides for Serious Brands</h1>
    <div class="gold-line"></div>
    <p class="intro">Free resources to help you plan production, choose materials, control costs, and ship globally. Built from 16 years of manufacturing experience.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">Download Guides</h2>
    <div class="gold-line"></div>
    <div class="resource-grid">
      <div class="card">
        <h3>Manufacturing Checklist</h3>
        <p>The step-by-step checklist for planning sampling, production, quality control, and delivery. Used by 100+ brands before their first production run.</p>
        <button class="btn btn-gold" onclick="openResourceGate('Manufacturing Checklist','TCG_Manufacturing_Checklist.pdf')">Download PDF</button>
      </div>
      <div class="card">
        <h3>Fabric Selection Guide</h3>
        <p>How to choose the right fabric for streetwear, activewear, basics, and uniforms. Includes weight recommendations, care properties, and cost ranges.</p>
        <button class="btn btn-gold" onclick="openResourceGate('Fabric Selection Guide','TCG_Fabric_Selection_Guide.pdf')">Download PDF</button>
      </div>
      <div class="card">
        <h3>Cost Optimization Strategies</h3>
        <p>Reduce production costs without sacrificing quality. Covers smart sourcing, order consolidation, and material efficiency.</p>
        <button class="btn btn-gold" onclick="openResourceGate('Cost Optimization Strategies','TCG_Cost_Optimization_Strategies.pdf')">Download PDF</button>
      </div>
      <div class="card">
        <h3>Quality Control Standards</h3>
        <p>Understand AQL inspection protocols, production quality benchmarks, and how to set expectations with your manufacturer.</p>
        <button class="btn btn-gold" onclick="openResourceGate('Quality Control Standards','TCG_Quality_Control_Standards.pdf')">Download PDF</button>
      </div>
      <div class="card">
        <h3>Sustainability in Manufacturing</h3>
        <p>Ethical and sustainable production practices for modern fashion brands. Covers certifications, materials, and supply chain transparency.</p>
        <button class="btn btn-gold" onclick="openResourceGate('Sustainability in Manufacturing','TCG_Sustainability_Guide.pdf')">Download PDF</button>
      </div>
      <div class="card">
        <h3>Global Shipping & Logistics</h3>
        <p>Plan documentation, shipping methods, customs clearance, and international delivery timelines from Bali to anywhere.</p>
        <button class="btn btn-gold" onclick="openResourceGate('Global Shipping & Logistics','TCG_Shipping_Logistics_Guide.pdf')">Download PDF</button>
      </div>
    </div>
  </div>
</section>

<!-- Resource Gate Modal -->
<div class="resource-modal" id="resourceModal" style="display:none;">
  <div class="resource-modal-content">
    <button class="resource-modal-close" onclick="closeResourceGate()">&times;</button>
    <h3 id="resourceModalTitle">Get Your Free Guide</h3>
    <p>Enter your details below and we will send the download link to your inbox.</p>
    <form id="resourceGateForm" onsubmit="submitResourceGate(event)">
      <input type="hidden" id="rgResource" value="">
      <input type="text" id="rgName" placeholder="Your Name" required>
      <input type="email" id="rgEmail" placeholder="Email Address" required>
      <input type="text" id="rgBrand" placeholder="Brand Name">
      <button type="submit" class="btn btn-gold">Send Download Link</button>
    </form>
  </div>
</div>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Need a Custom Production Plan?</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Our team can create a tailored manufacturing plan for your brand — quantities, timelines, pricing, and logistics mapped out before you commit.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Request a Free Production Plan</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
