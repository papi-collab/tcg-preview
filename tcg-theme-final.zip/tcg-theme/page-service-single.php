<?php /* Template Name: Service Single */ get_header(); 
$slug = get_post_field('post_name', get_post());
$services = array(
  'sampling' => array(
    'title' => 'Sampling & Pattern Making',
    'intro' => 'We turn your design concept into a production-ready pattern and physical sample. Approve everything before a single bulk unit is cut.',
    'pain_title' => 'Stop Guessing. Approve Before You Commit.',
    'pain_body' => 'The most expensive mistake in garment manufacturing is going to bulk without proper sampling. Fit issues, construction problems, and fabric surprises multiply at scale. We eliminate that risk by developing accurate patterns and producing samples you can hold, wear, and approve before production begins.',
    'includes' => array(
      'Pattern development from tech pack, sketch, or reference garment',
      'Digital pattern grading across your full size range',
      'First sample production (1-2 units)',
      'Fit review and adjustment rounds',
      'Fabric testing and shrinkage checks',
      'Production-ready pattern package for bulk'
    ),
    'process' => array(
      array('Submit your design', 'Send a tech pack, sketch, reference garment, or description. We confirm feasibility within 24 hours.'),
      array('Pattern development', 'Our team creates the pattern and confirms construction details with you.'),
      array('Sample production', 'We produce 1-2 sample units in your chosen fabric.'),
      array('Review and revise', 'You receive the sample, test the fit, and request any adjustments.'),
      array('Approval', 'Once you approve, the pattern is locked for bulk production.')
    ),
    'timeline' => '7-14 days from submission to sample delivery.',
    'faq' => array(
      'How much does a sample cost?' => 'Sample pricing depends on garment complexity. Basic tees start at $30-50/sample. Complex outerwear may be $80-150. We provide exact pricing before starting.',
      'Can you work from a sketch instead of a tech pack?' => 'Yes. We can develop patterns from sketches, reference garments, or even photos with measurements. A tech pack speeds things up but is not required.',
      'How many revision rounds are included?' => 'We include up to 2 revision rounds in standard sampling. Additional rounds are charged at cost.',
      'Do I own the pattern?' => 'Yes. All patterns developed for your brand belong to you.'
    ),
    'cta_title' => 'Start With a Sample',
    'cta_body' => 'Send us your design and we will quote sampling within 24 hours.'
  ),
  'fabric-sourcing' => array(
    'title' => 'Fabric Sourcing & Materials',
    'intro' => 'We source the right fabric for your product — performance, weight, hand feel, sustainability, and price point. No guesswork.',
    'pain_title' => 'The Wrong Fabric Kills a Good Design.',
    'pain_body' => 'Fabric is the foundation of every garment. Choose wrong and you get pilling, shrinkage, poor drape, or customer returns. We source from trusted mills with tested quality, and we send you swatches before committing to bulk yardage.',
    'includes' => array(
      'Premium cottons (combed, ring-spun, organic)',
      'Technical performance fabrics (moisture-wicking, 4-way stretch)',
      'Sustainable and recycled options (GOTS certified, recycled poly)',
      'Custom dyeing and color matching (Pantone)',
      'Fabric testing (shrinkage, colorfastness, weight)',
      'Swatch packages before bulk commitment'
    ),
    'process' => array(
      array('Tell us your product type', 'Describe the garment, its use case, and any fabric preferences.'),
      array('We recommend options', 'Our team provides fabric recommendations with pricing and swatch availability.'),
      array('Swatch review', 'We send physical swatches for you to evaluate hand feel, weight, and color.'),
      array('Fabric confirmation', 'You approve the fabric and we source the required yardage for production.'),
      array('Quality testing', 'We test for shrinkage, colorfastness, and weight before cutting.')
    ),
    'timeline' => '3-7 days for swatch delivery. Bulk fabric sourcing: 7-14 days.',
    'faq' => array(
      'Can you source organic or sustainable fabrics?' => 'Yes. We work with GOTS-certified organic cotton, recycled polyester, and other sustainable materials.',
      'Do you provide fabric swatches before production?' => 'Always. You receive physical swatches to approve before we commit to bulk yardage.',
      'Can you match a specific Pantone color?' => 'Yes. We offer custom dyeing and Pantone color matching for all fabric types.',
      'What fabric weights do you carry?' => 'We source everything from lightweight 120gsm jersey to heavy 400gsm+ fleece and outerwear fabrics.'
    ),
    'cta_title' => 'Need Help Choosing Fabric?',
    'cta_body' => 'Tell us your product type and we will recommend the right material with pricing.'
  ),
  'cut-and-sew' => array(
    'title' => 'Cut & Sew Production',
    'intro' => 'Full garment construction from 50 to 10,000+ units per month. Consistent sizing, premium finishing, and on-time delivery.',
    'pain_title' => 'Production That Runs on Schedule. Every Time.',
    'pain_body' => 'Late deliveries kill product launches. Inconsistent sizing creates returns. Poor finishing damages brand reputation. Our cut and sew production runs on locked timelines with quality checks at every stage. You get the units you ordered, when you ordered them, built to the standard you approved in sampling.',
    'includes' => array(
      'Marker making and fabric cutting (manual and automated)',
      'Full garment assembly and construction',
      'Seam finishing (flatlock, overlock, coverstitch, French seam)',
      'Size grading and consistent sizing across full runs',
      'In-line quality inspection at every production stage',
      'Final pressing, folding, and packaging'
    ),
    'process' => array(
      array('Approved sample received', 'Your approved sample becomes the production standard.'),
      array('Fabric cutting', 'Marker making and precision cutting for all sizes.'),
      array('Assembly', 'Full garment construction with in-line quality checks.'),
      array('Finishing', 'Pressing, trimming, and final inspection.'),
      array('Packing and delivery', 'Folded, tagged, and packed for shipping.')
    ),
    'timeline' => '4-8 weeks for bulk production depending on quantity and complexity.',
    'faq' => array(
      'What is the minimum order quantity?' => 'Our MOQ starts at 50 units per style/color. This makes us accessible for emerging brands while maintaining production efficiency.',
      'What is your monthly production capacity?' => '10,000+ units per month across all garment categories.',
      'Do you handle size grading?' => 'Yes. We grade patterns across your full size range and ensure consistent sizing throughout the production run.',
      'What seam types do you offer?' => 'We offer flatlock, overlock, coverstitch, French seam, and more depending on garment requirements.'
    ),
    'cta_title' => 'Get Production Pricing',
    'cta_body' => 'Tell us your style, quantity, and timeline. We respond within 24 hours.'
  ),
  'printing-embroidery' => array(
    'title' => 'Printing & Embroidery',
    'intro' => 'Your artwork applied with precision. Screen printing, DTG, sublimation, and embroidery at any volume.',
    'pain_title' => 'Your Art. Applied Right. At Scale.',
    'pain_body' => 'Bad printing ruins good designs. Colors shift, placements drift, and detail gets lost at volume. We lock color matching, placement accuracy, and print durability before bulk runs begin. Every decorated garment matches your approved sample.',
    'includes' => array(
      'Screen printing (up to 8 colors, water-based and plastisol)',
      'Direct-to-garment (DTG) for complex artwork and photo prints',
      'Sublimation for all-over prints and performance fabrics',
      'Embroidery (flat, 3D puff, chain stitch)',
      'Applique and patch work',
      'Heat transfer and vinyl'
    ),
    'process' => array(
      array('Submit your artwork', 'Send your design files and we recommend the best decoration method.'),
      array('Method confirmation', 'We confirm the technique, placement, and color matching.'),
      array('Sample production', 'We produce a decorated sample for your approval.'),
      array('Bulk decoration', 'Full production run with consistent quality.'),
      array('Quality check', 'Every decorated garment inspected before packing.')
    ),
    'timeline' => '3-5 days for print samples. Bulk decoration: included in production timeline.',
    'faq' => array(
      'Which printing method is best for my design?' => 'It depends on your artwork complexity, fabric type, and quantity. We recommend the best method after reviewing your files.',
      'Can you color match to Pantone?' => 'Yes. We offer Pantone color matching for screen printing and embroidery thread.',
      'What is the maximum print size?' => 'Screen printing supports up to 40cm x 50cm. Sublimation supports all-over prints with no size limit.',
      'Do you offer 3D puff embroidery?' => 'Yes. We offer flat, 3D puff, and chain stitch embroidery for logos and designs.'
    ),
    'cta_title' => 'Get Decoration Pricing',
    'cta_body' => 'Send your artwork and we will recommend the best method with pricing per unit.'
  ),
  'quality-control' => array(
    'title' => 'Quality Control & Inspection',
    'intro' => 'Multi-stage inspection at every production phase. Nothing ships without passing QC.',
    'pain_title' => 'Catch Problems Before They Reach Your Customer.',
    'pain_body' => 'Quality issues found after delivery cost 10x more to fix than issues caught in production. We inspect at fabric stage, during construction, after finishing, and before packing. AQL 2.5 standard. Detailed QC reports with photos for every shipment.',
    'includes' => array(
      'Incoming fabric inspection (weight, color, defects)',
      'In-line production checks (stitching, construction, sizing)',
      'End-of-line inspection (finishing, pressing, labeling)',
      'Final audit before packing (AQL 2.5 standard)',
      'QC photo reports sent to client before shipment',
      'Measurement checks against approved spec sheet'
    ),
    'process' => array(
      array('Fabric inspection', 'Check weight, color consistency, and defects before cutting.'),
      array('In-line checks', 'Monitor stitching, construction, and sizing during assembly.'),
      array('End-of-line inspection', 'Verify finishing, pressing, and labeling quality.'),
      array('Final audit', 'AQL 2.5 standard inspection before packing.'),
      array('QC report', 'Photo report sent to client before shipment approval.')
    ),
    'timeline' => 'Integrated into production — no additional time added.',
    'faq' => array(
      'What AQL standard do you use?' => 'We use AQL 2.5 as our standard inspection level. Tighter standards available on request.',
      'Do I receive QC reports?' => 'Yes. Every shipment includes a detailed QC photo report before goods leave our facility.',
      'Is quality control included in the price?' => 'Yes. Multi-stage QC is included in every TCG production run at no additional cost.',
      'What happens if defects are found?' => 'Defective units are flagged, repaired, or replaced before shipment. You are notified immediately.'
    ),
    'cta_title' => 'Production With Built-In Quality Control',
    'cta_body' => 'Every TCG production run includes full QC at no additional cost.'
  ),
  'packaging-shipping' => array(
    'title' => 'Packaging & Global Shipping',
    'intro' => 'Custom labels, tags, retail-ready packaging, and door-to-door logistics from Bali to anywhere in the world.',
    'pain_title' => 'Delivered to Your Door. Ready to Sell.',
    'pain_body' => 'Production is only half the job. We handle everything after the last stitch — custom branding, retail packaging, export documentation, and shipping logistics. Your goods arrive at your warehouse folded, tagged, bagged, and ready for your customer.',
    'includes' => array(
      'Custom woven labels and printed care labels',
      'Hang tags, price tags, and brand cards',
      'Individual poly bagging or retail-ready packaging',
      'Carton packing with packing lists',
      'Export documentation and customs paperwork',
      'Sea freight (10-21 days) or air freight (3-5 days)',
      'Door-to-door delivery coordination'
    ),
    'process' => array(
      array('Packaging design', 'Confirm labels, tags, and packaging specifications.'),
      array('Label production', 'Woven labels, care labels, and hang tags produced.'),
      array('Packing', 'Garments folded, bagged, and packed into cartons.'),
      array('Export documentation', 'All customs paperwork and export docs prepared.'),
      array('Shipping', 'Sea or air freight coordinated door-to-door.')
    ),
    'timeline' => 'Packaging: 3-5 days. Sea freight: 5-21 days. Air freight: 2-7 days.',
    'faq' => array(
      'Do you handle customs paperwork?' => 'Yes. We manage all export documentation and customs clearance.',
      'Can you ship directly to my fulfillment center?' => 'Yes. We coordinate door-to-door delivery to any address worldwide.',
      'What shipping methods are available?' => 'Sea freight (most cost-effective) and air freight (fastest). We recommend based on your timeline and budget.',
      'Can you do retail-ready packaging?' => 'Yes. Individual poly bags, hang tags, price tags, and brand cards — ready for your shelf or fulfillment center.'
    ),
    'cta_title' => 'Get a Shipping Estimate',
    'cta_body' => 'Tell us your destination and quantity. We will quote packaging and logistics.'
  )
);

// Determine which service to show
$service_slug = str_replace('services/', '', $slug);
$service_slug = rtrim($service_slug, '/');
if(!isset($services[$service_slug])){
  // Try to extract from URL
  $parts = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
  $service_slug = end($parts);
}
$s = isset($services[$service_slug]) ? $services[$service_slug] : null;
if(!$s){ echo '<div class="container section"><p>Service not found.</p></div>'; get_footer(); return; }
?>

<section class="service-hero">
  <div class="container">
    <div class="breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a> &raquo; <a href="<?php echo home_url('/services/'); ?>">Services</a> &raquo; <?php echo $s['title']; ?></div>
    <h1 class="h1"><?php echo $s['title']; ?></h1>
    <div class="gold-line"></div>
    <p class="intro"><?php echo $s['intro']; ?></p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title"><?php echo $s['pain_title']; ?></h2>
    <div class="gold-line"></div>
    <p class="intro"><?php echo $s['pain_body']; ?></p>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <h2 class="section-title">What You Get</h2>
    <div class="gold-line"></div>
    <ul class="service-list">
      <?php foreach($s['includes'] as $item): ?>
      <li><?php echo $item; ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">How It Works</h2>
    <div class="gold-line"></div>
    <div class="steps">
      <?php foreach($s['process'] as $i => $step): ?>
      <div class="step">
        <h3><?php echo $step[0]; ?></h3>
        <p><?php echo $step[1]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <p class="intro mt-24"><strong>Timeline:</strong> <?php echo $s['timeline']; ?></p>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <h2 class="section-title">Common Questions</h2>
    <div class="gold-line"></div>
    <div class="faq">
      <?php foreach($s['faq'] as $q => $a): ?>
      <details>
        <summary><?php echo $q; ?></summary>
        <p><?php echo $a; ?></p>
      </details>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title"><?php echo $s['cta_title']; ?></h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;"><?php echo $s['cta_body']; ?></p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Request a Quote</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
