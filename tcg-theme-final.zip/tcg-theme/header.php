<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="index, follow">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Oswald:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<nav class="nav" id="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="<?php echo home_url('/'); ?>"><img src="<?php echo home_url('/wp-content/uploads/logos/TCG_Logo_Nav.png'); ?>" alt="The Clothing Guys - Premium Garment Manufacturing" class="nav-logo" id="site-nav-logo"></a>
        <div class="nav-links">
            <a href="<?php echo home_url('/'); ?>">Home</a>
            <div class="nav-dropdown">
                <a href="<?php echo home_url('/services/'); ?>">Services</a>
                <div class="nav-dropdown-menu">
                    <a href="<?php echo home_url('/services/sampling/'); ?>">Sampling & Pattern Making</a>
                    <a href="<?php echo home_url('/services/fabric-sourcing/'); ?>">Fabric Sourcing</a>
                    <a href="<?php echo home_url('/services/cut-and-sew/'); ?>">Cut & Sew Production</a>
                    <a href="<?php echo home_url('/services/printing-embroidery/'); ?>">Printing & Embroidery</a>
                    <a href="<?php echo home_url('/services/quality-control/'); ?>">Quality Control</a>
                    <a href="<?php echo home_url('/services/packaging-shipping/'); ?>">Packaging & Shipping</a>
                </div>
            </div>
            <a href="<?php echo home_url('/about/'); ?>">About</a>
            <a href="<?php echo home_url('/process/'); ?>">Process</a>
            <a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a>
            <a href="<?php echo home_url('/resources/'); ?>">Resources</a>
            <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
        </div>
        <button class="hamb" onclick="toggleMenu()" aria-label="Menu">&#9776;</button>
    </div>
    <!-- Mobile: single row with TCG logo + nav links + hamburger -->
    <div class="mobile-top-nav">
        <a class="mobile-tcg-logo" href="<?php echo home_url('/'); ?>"><img src="<?php echo home_url('/wp-content/uploads/logos/TCG_Logo_Nav.png'); ?>" alt="TCG"></a>
        <div class="mobile-nav-scroll">
            <a href="<?php echo home_url('/'); ?>">Home</a>
            <a href="<?php echo home_url('/services/'); ?>">Services</a>
            <a href="<?php echo home_url('/about/'); ?>">About</a>
            <a href="<?php echo home_url('/process/'); ?>">Process</a>
            <a href="<?php echo home_url('/case-studies/'); ?>">Cases</a>
            <a href="<?php echo home_url('/resources/'); ?>">Resources</a>
        </div>
        <button class="hamb mobile-hamb" onclick="toggleMenu()" aria-label="Menu">&#9776;</button>
    </div>
    <!-- Mobile: full dropdown menu (hamburger) -->
    <div class="mobile" id="mobile-menu">
        <a href="<?php echo home_url('/'); ?>">Home</a>
        <a href="<?php echo home_url('/services/'); ?>">Services</a>
        <a href="<?php echo home_url('/services/sampling/'); ?>" class="sub">Sampling & Pattern Making</a>
        <a href="<?php echo home_url('/services/fabric-sourcing/'); ?>" class="sub">Fabric Sourcing</a>
        <a href="<?php echo home_url('/services/cut-and-sew/'); ?>" class="sub">Cut & Sew Production</a>
        <a href="<?php echo home_url('/services/printing-embroidery/'); ?>" class="sub">Printing & Embroidery</a>
        <a href="<?php echo home_url('/services/quality-control/'); ?>" class="sub">Quality Control</a>
        <a href="<?php echo home_url('/services/packaging-shipping/'); ?>" class="sub">Packaging & Shipping</a>
        <a href="<?php echo home_url('/about/'); ?>">About</a>
        <a href="<?php echo home_url('/process/'); ?>">Process</a>
        <a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a>
        <a href="<?php echo home_url('/resources/'); ?>">Resources</a>
    </div>
</nav>
<?php if(!is_front_page()): ?>
<div class="breadcrumb-bar">
    <div class="container">
        <a href="<?php echo home_url('/'); ?>">Home</a> &raquo; <span><?php the_title(); ?></span>
    </div>
</div>
<?php endif; ?>
<main>
