<?php /* Template Name: Process */ get_header(); ?>

<section class="section alt hero-bg" style="background:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url(/wp-content/uploads/logos/background-1.jpg) center/cover no-repeat;color:#fff">
  <div class="container">
    <h1 class="h1">From Concept to Delivery — No Surprises</h1>
    <div class="gold-line"></div>
    <p class="intro">A transparent production workflow designed to reduce uncertainty and protect your investment at every stage.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">The Simple Version</h2>
    <div class="gold-line"></div>
    <div class="grid-3">
      <div class="card card-center">
        <div class="icon">1</div>
        <h3>Tell Us What You Need</h3>
        <p>Share your designs, quantities, and timeline.</p>
      </div>
      <div class="card card-center">
        <div class="icon">2</div>
        <h3>Approve Before Bulk</h3>
        <p>We produce samples. You approve fit, fabric, and construction.</p>
      </div>
      <div class="card card-center">
        <div class="icon">3</div>
        <h3>We Manufacture and Ship</h3>
        <p>Production runs on schedule. QC at every stage. Delivered to your door.</p>
      </div>
    </div>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <h2 class="section-title">The Full Production Workflow</h2>
    <div class="gold-line"></div>
    <p class="intro">For brands that want to understand exactly what happens at each stage.</p>
    <div class="steps mt-24">
      <div class="step">
        <h3>Consultation</h3>
        <p>You tell us what you need — product type, quantity, timeline, and budget. We confirm feasibility, recommend materials, and provide initial pricing within 24-48 hours.</p>
      </div>
      <div class="step">
        <h3>Tech Pack & Pattern Development</h3>
        <p>We review your tech pack (or create one from your sketch/reference). Patterns are developed and confirmed with you before sampling begins.</p>
      </div>
      <div class="step">
        <h3>Sampling</h3>
        <p>We produce 1-2 sample units in your chosen fabric. You receive the physical sample to test fit, construction, and finishing.</p>
      </div>
      <div class="step">
        <h3>Fit Approval & Revisions</h3>
        <p>You review the sample, request any adjustments, and give final approval. Nothing goes to bulk until you sign off.</p>
      </div>
      <div class="step">
        <h3>Bulk Production</h3>
        <p>Production begins using your approved sample as the standard. In-line quality checks at every stage. Regular progress updates.</p>
      </div>
      <div class="step">
        <h3>Quality Control</h3>
        <p>Multi-stage inspection: fabric, construction, finishing, and final audit. AQL 2.5 standard. QC photo report sent before shipment.</p>
      </div>
      <div class="step">
        <h3>Packaging & Global Shipping</h3>
        <p>Custom labels, tags, and retail-ready packaging. We handle export documentation and coordinate door-to-door delivery to your warehouse.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">Typical Timelines</h2>
    <div class="gold-line"></div>
    <div class="quick-facts" style="max-width:700px;">
      <table>
        <tr><td>Consultation to quote</td><td>24-48 hours</td></tr>
        <tr><td>Pattern development</td><td>5-7 days</td></tr>
        <tr><td>Sampling</td><td>7-14 days</td></tr>
        <tr><td>Approval & revisions</td><td>3-7 days</td></tr>
        <tr><td>Bulk production</td><td>4-8 weeks</td></tr>
        <tr><td>Quality control</td><td>Integrated (no added time)</td></tr>
        <tr><td>Shipping (sea)</td><td>5-21 days depending on destination</td></tr>
      </table>
    </div>
    <p class="intro mt-24"><strong>Total typical timeline:</strong> 8-12 weeks from first contact to delivery.</p>
  </div>
</section>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Start the Process</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Tell us what you need. We respond within 24 hours with a plan, pricing, and timeline.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Free Quote</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
