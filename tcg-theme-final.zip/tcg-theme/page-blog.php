<?php
/**
 * Template Name: Blog Page
 */
get_header(); ?>
<section class="section alt">
    <div class="container">
        <h1 class="section-title">Manufacturing Insights for Fashion Brands</h1>
        <div class="gold-line"></div>
        <p class="intro">Educational content for brands planning sampling, production, quality control, and growth.</p>
    </div>
</section>
<section class="section">
    <div class="container blog-list">
        <article class="card">
            <h3>How to Choose a Clothing Manufacturer</h3>
            <p>What serious fashion brands should look for before choosing a production partner.</p>
            <a href="<?php echo home_url('/blog-choose-manufacturer/'); ?>">Read more &rarr;</a>
        </article>
        <article class="card">
            <h3>What Is MOQ?</h3>
            <p>How minimum order quantities affect pricing, sampling, and scaling.</p>
            <a href="<?php echo home_url('/blog-what-is-moq/'); ?>">Read more &rarr;</a>
        </article>
        <article class="card">
            <h3>Streetwear Manufacturing Guide</h3>
            <p>Fabric, fit, printing, embroidery, and production planning for streetwear brands.</p>
            <a href="<?php echo home_url('/blog-streetwear-guide/'); ?>">Read more &rarr;</a>
        </article>
        <article class="card">
            <h3>Activewear Manufacturing Guide</h3>
            <p>Technical fabrics, fit engineering, and scalable activewear production.</p>
            <a href="<?php echo home_url('/blog-activewear-guide/'); ?>">Read more &rarr;</a>
        </article>
        <article class="card">
            <h3>Bali vs China Manufacturing</h3>
            <p>How Bali compares as a flexible offshore production destination.</p>
            <a href="<?php echo home_url('/blog-bali-vs-china/'); ?>">Read more &rarr;</a>
        </article>
        <article class="card">
            <h3>Quality Control in Garment Production</h3>
            <p>How inspection systems protect your brand before shipment.</p>
            <a href="<?php echo home_url('/blog-quality-control/'); ?>">Read more &rarr;</a>
        </article>
    </div>
</section>
<?php get_footer(); ?>
