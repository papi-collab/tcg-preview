<?php
/**
 * Front Page Template - loads home page content
 */
include(get_template_directory() . '/page-home.php');
