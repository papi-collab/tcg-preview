<?php
/**
 * Template Name: Category Landing Page
 */
get_header();

$slug = get_post_field('post_name', get_post());
$cat_data = array(
    'streetwear' => array(
        'title' => 'Streetwear Manufacturer',
        'desc' => 'Premium streetwear manufacturing for modern brands. Oversized fits, heavyweight cottons, screen printing, embroidery, and seasonal drop production.',
        'features' => array(
            array('title' => 'Heavyweight Fabrics', 'desc' => 'Premium 280-400gsm cottons, French terry, and custom fleece options for authentic streetwear weight and feel.'),
            array('title' => 'Print & Embroidery', 'desc' => 'Screen printing, puff print, DTG, sublimation, chain stitch, and flat embroidery for bold streetwear graphics.'),
            array('title' => 'Oversized & Boxy Fits', 'desc' => 'Expert pattern making for oversized, boxy, and drop-shoulder silhouettes that define modern streetwear.'),
            array('title' => 'Seasonal Drops', 'desc' => 'Fast turnaround production designed for seasonal collections, limited runs, and capsule drops.')
        )
    ),
    'activewear' => array(
        'title' => 'Activewear Manufacturer',
        'desc' => 'Technical activewear manufacturing for performance brands. Moisture-wicking fabrics, compression fits, sublimation printing, and scalable production.',
        'features' => array(
            array('title' => 'Performance Fabrics', 'desc' => 'Moisture-wicking polyester, nylon blends, compression fabrics, and recycled performance materials.'),
            array('title' => 'Technical Construction', 'desc' => 'Flatlock seaming, bonded hems, laser cutting, and athletic-grade construction techniques.'),
            array('title' => 'Precision Fit', 'desc' => 'Engineered sizing for athletic performance including compression, relaxed, and fitted silhouettes.'),
            array('title' => 'Finishing Options', 'desc' => 'Sublimation printing, heat transfers, reflective details, and custom labeling for activewear.')
        )
    ),
    'womenswear' => array(
        'title' => 'Womenswear Manufacturer',
        'desc' => 'Premium womenswear manufacturing for fashion brands. Delicate fabrics, precise construction, and scalable production for dresses, tops, and collections.',
        'features' => array(
            array('title' => 'Delicate Fabrics', 'desc' => 'Silk, chiffon, linen, viscose, and premium cotton handling with expert care and precision.'),
            array('title' => 'Precise Construction', 'desc' => 'Detailed finishing, invisible zippers, French seams, and couture-level construction techniques.'),
            array('title' => 'Size Inclusivity', 'desc' => 'Expert grading across extended size ranges with fit consistency across all sizes.'),
            array('title' => 'Collection Production', 'desc' => 'Full collection manufacturing from resort wear to evening wear with cohesive quality throughout.')
        )
    ),
    'uniforms' => array(
        'title' => 'Uniform Manufacturer',
        'desc' => 'Professional uniform manufacturing for hospitality, corporate, and industrial brands. Durable fabrics, consistent sizing, and bulk production.',
        'features' => array(
            array('title' => 'Durable Fabrics', 'desc' => 'Industrial-grade polyester blends, cotton twills, and performance fabrics built for daily wear and frequent washing.'),
            array('title' => 'Consistent Sizing', 'desc' => 'Standardized sizing across all production runs with strict measurement tolerances for uniform consistency.'),
            array('title' => 'Branding Options', 'desc' => 'Embroidered logos, woven labels, printed badges, and custom hardware for professional branding.'),
            array('title' => 'Bulk Production', 'desc' => 'High-volume production capability for multi-location rollouts with consistent quality and timely delivery.')
        )
    ),
);

$data = isset($cat_data[$slug]) ? $cat_data[$slug] : $cat_data['streetwear'];
?>

<section class="section alt">
    <div class="container">
        <h1 class="section-title"><?php echo esc_html($data['title']); ?></h1>
        <div class="gold-line"></div>
        <p class="intro"><?php echo esc_html($data['desc']); ?></p>
    </div>
</section>

<section class="section">
    <div class="container">
        <h2 class="section-title">Specialized Capabilities</h2>
        <div class="gold-line"></div>
        <div class="grid-2">
            <?php foreach ($data['features'] as $feature) : ?>
            <div class="card">
                <h3><?php echo esc_html($feature['title']); ?></h3>
                <p><?php echo esc_html($feature['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section alt">
    <div class="container">
        <h2 class="section-title">Full-Service Manufacturing</h2>
        <div class="gold-line"></div>
        <p class="intro">We manage the production lifecycle from concept to delivery.</p>
        <div class="grid-2">
            <div class="card">
                <h3>Design &amp; Development</h3>
                <p>Pattern making, fit refinement, sampling, and prototyping.</p>
            </div>
            <div class="card">
                <h3>Fabric &amp; Materials</h3>
                <p>Premium cottons, technical fabrics, sustainable options, custom milling, and dyeing.</p>
            </div>
            <div class="card">
                <h3>Production &amp; Printing</h3>
                <p>Cut and sew production, screen printing, digital printing, embroidery, and finishing.</p>
            </div>
            <div class="card">
                <h3>Packaging &amp; Logistics</h3>
                <p>Labels, tags, retail-ready packaging, quality control, and global shipping support.</p>
            </div>
        </div>
    </div>
</section>

<section class="section dark">
    <div class="container" style="text-align:center">
        <h2 class="section-title">Ready to Start Your Project?</h2>
        <p class="intro" style="margin:auto auto 24px">Get a detailed quote for your manufacturing needs. Our team will respond within 24 hours.</p>
        <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Request a Quote</a>
    </div>
</section>

<?php get_footer(); ?>
