</main>
<footer class="footer">
  <div class="container">
    <div class="footer-brand-center">
      <img src="<?php echo home_url('/wp-content/uploads/logos/TCG_Logo_White.png'); ?>" alt="The Clothing Guys" class="footer-logo">
      <p class="footer-desc">Premium garment manufacturing from Bali, Indonesia. From 50-unit sampling to 10,000-unit production runs. On time. On spec. Full transparency.</p>
    </div>
    <div class="footer-grid footer-grid-3col">
      <div>
        <h4>Services</h4>
        <a href="<?php echo home_url('/services/sampling/'); ?>">Sampling & Pattern Making</a>
        <a href="<?php echo home_url('/services/fabric-sourcing/'); ?>">Fabric Sourcing</a>
        <a href="<?php echo home_url('/services/cut-and-sew/'); ?>">Cut & Sew Production</a>
        <a href="<?php echo home_url('/services/printing-embroidery/'); ?>">Printing & Embroidery</a>
        <a href="<?php echo home_url('/services/quality-control/'); ?>">Quality Control</a>
        <a href="<?php echo home_url('/services/packaging-shipping/'); ?>">Packaging & Shipping</a>
      </div>
      <div>
        <h4>Company</h4>
        <a href="<?php echo home_url('/about/'); ?>">About</a>
        <a href="<?php echo home_url('/process/'); ?>">Process</a>
        <a href="<?php echo home_url('/case-studies/'); ?>">Case Studies</a>
        <a href="<?php echo home_url('/resources/'); ?>">Resources</a>
        <a href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
        <h4 class="footer-contact-h4">Contact</h4>
        <a href="mailto:info@theclothingguys.com">info@theclothingguys.com</a>
        <a href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie: +62 822 3010 0897</a>
      </div>
      <div>
        <h4>Regions</h4>
        <a href="<?php echo home_url('/clothing-manufacturer-usa/'); ?>">USA</a>
        <a href="<?php echo home_url('/clothing-manufacturer-canada/'); ?>">Canada</a>
        <a href="<?php echo home_url('/clothing-manufacturer-australia/'); ?>">Australia</a>
        <a href="<?php echo home_url('/bali-clothing-manufacturer/'); ?>">Bali</a>
        <a href="<?php echo home_url('/indonesia-garment-manufacturer/'); ?>">Southeast Asia</a>
        <h4 class="footer-contact-h4">Categories</h4>
        <a href="<?php echo home_url('/streetwear/'); ?>">Streetwear</a>
        <a href="<?php echo home_url('/activewear/'); ?>">Activewear</a>
        <a href="<?php echo home_url('/womenswear/'); ?>">Womenswear</a>
        <a href="<?php echo home_url('/uniforms/'); ?>">Uniforms</a>
      </div>
    </div>
    <div class="footer-bottom">
      &copy; <?php echo date('Y'); ?> The Clothing Guys. All rights reserved. | <a href="<?php echo home_url('/'); ?>?tcg-sitemap=xml">Sitemap</a>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
