<?php /* Template Name: About */ get_header(); ?>

<section class="section alt hero-bg" style="background:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url(/wp-content/uploads/logos/background-1.jpg) center/cover no-repeat;color:#fff">
  <div class="container">
    <h1 class="h1">Built to Solve the Problems Other Factories Create</h1>
    <div class="gold-line"></div>
    <p class="intro">The Clothing Guys exists because too many brands get burned by manufacturers that overpromise and underdeliver. We built a production company around the things most factories get wrong: communication, consistency, and accountability.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">The Story</h2>
    <div class="gold-line"></div>
    <div class="two-col">
      <div>
        <p class="intro">Founded as BaliLab in 2010, The Clothing Guys started with one question: why is it so hard for small brands to find a reliable manufacturer?</p>
        <p class="intro" style="margin-top:16px;">The answer was clear. Most factories are built for volume, not for partnership. They take your deposit, disappear for weeks, and deliver something different from what you approved. Communication is an afterthought. Timelines are suggestions.</p>
        <p class="intro" style="margin-top:16px;">We built TCG to be the opposite. One point of contact. Transparent timelines. Samples you approve before bulk. Quality checks at every stage. And a team that actually responds when you message.</p>
        <p class="intro" style="margin-top:16px;">Sixteen years later, we have produced for over 100 brands across 12 countries — from 50-unit startup runs to 10,000-unit monthly production. The model has not changed: treat every brand like a partner, not a purchase order number.</p>
      </div>
      <div>
        <div class="quick-facts">
          <table>
            <tr><td>Founded</td><td>2010 (as BaliLab)</td></tr>
            <tr><td>Location</td><td>Bali, Indonesia</td></tr>
            <tr><td>Experience</td><td>16+ years</td></tr>
            <tr><td>MOQ</td><td>50 units per style</td></tr>
            <tr><td>Monthly Capacity</td><td>10,000+ units</td></tr>
            <tr><td>On-Time Delivery</td><td>99%</td></tr>
            <tr><td>Brands Served</td><td>100+ globally</td></tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <h2 class="section-title">How We Work</h2>
    <div class="gold-line"></div>
    <div class="grid-3">
      <div class="card card-center">
        <h3>Transparent Communication</h3>
        <p>You will never wonder where your production is. We provide real-time updates, clear timelines, and honest answers — even when the answer is "we need more time."</p>
      </div>
      <div class="card card-center">
        <h3>Quality Without Compromise</h3>
        <p>Every garment passes multi-stage quality control. We catch problems in production, not after delivery. AQL 2.5 standard on every shipment.</p>
      </div>
      <div class="card card-center">
        <h3>Ethical Production</h3>
        <p>Fair wages, safe working conditions, and sustainable practices are non-negotiable. We produce garments we are proud to put our name behind.</p>
      </div>
    </div>
  </div>
</section>

<section class="section dark" id="page-footer-cta">
  <div class="container text-center">
    <h2 class="section-title">Ready to Work With a Factory That Shows Up?</h2>
    <p class="intro" style="color:#e9e9e9;margin:0 auto 28px;text-align:center;">Tell us about your brand. We respond within 24 hours.</p>
    <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Start a Conversation</a>
  </div>
</section>

<div class="sticky-cta" id="sticky-cta">
  <a class="btn btn-gold" href="<?php echo home_url('/quote/'); ?>">Get a Quote</a>
  <a class="btn btn-whatsapp" href="https://wa.me/6282230100897?text=Hi%20Frankie%2C%20I%27m%20interested%20in%20getting%20a%20quote%20for%20my%20clothing%20brand." target="_blank" rel="noopener">Chat with Frankie</a>
</div>

<?php get_footer(); ?>
